@echo off
title NetScope AI Launcher
echo ========================================================
echo         NetScope AI - Detect. Analyze. Replay.
echo ========================================================
echo.
echo Launching NetScope AI Cybersecurity Dashboard...
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not found on your system!
    echo Please install Node.js from https://nodejs.org to run this project.
    echo.
    pause
    exit /b
)

if exist dist (
    echo Starting pre-built production version...
    start http://localhost:5173
    call npx -y serve dist -l 5173 -s
) else (
    echo Starting development server...
    if not exist node_modules (
        echo Installing dependencies (this only happens once)...
        call npm install
    )
    start http://localhost:5173
    call npm run dev
)

pause
