import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useMonitoring } from '../../context/MonitoringContext';
import { SeverityBadge } from './SeverityBadge';
import { 
  X, 
  ShieldAlert, 
  Play
} from 'lucide-react';

export const AlertDetailModal: React.FC = () => {
  const { selectedAlertForDetail, setSelectedAlertForDetail } = useMonitoring();
  const navigate = useNavigate();

  if (!selectedAlertForDetail) return null;
  const alert = selectedAlertForDetail;

  const handleReplayAttack = () => {
    setSelectedAlertForDetail(null);
    navigate('/replay');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div 
        className="relative w-full max-w-2xl rounded-2xl border border-slate-700 bg-[#0d131f] p-6 shadow-2xl text-slate-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <span className="p-2 rounded-lg bg-red-500/10 text-red-400 border border-red-500/20">
              <ShieldAlert className="w-6 h-6" />
            </span>
            <div>
              <h2 className="text-xl font-bold font-mono text-white uppercase tracking-tight">
                🚨 {alert.attackType.toUpperCase()} DETECTED
              </h2>
              <p className="text-xs font-mono text-slate-400 mt-0.5">
                Alert ID: {alert.id}
              </p>
            </div>
          </div>

          <button
            onClick={() => setSelectedAlertForDetail(null)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 4 Metadata Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 my-5 font-mono text-xs">
          <div className="rounded-lg border border-slate-800 bg-[#090d16] p-3">
            <span className="text-slate-400 uppercase text-[10px] block">Source</span>
            <span className="text-cyan-300 font-bold mt-1 block">{alert.sourceIp}</span>
          </div>

          <div className="rounded-lg border border-slate-800 bg-[#090d16] p-3">
            <span className="text-slate-400 uppercase text-[10px] block">Destination</span>
            <span className="text-blue-300 font-bold mt-1 block">{alert.destinationIp}</span>
          </div>

          <div className="rounded-lg border border-slate-800 bg-[#090d16] p-3">
            <span className="text-slate-400 uppercase text-[10px] block">Time</span>
            <span className="text-white font-bold mt-1 block">{alert.timestamp}</span>
          </div>

          <div className="rounded-lg border border-slate-800 bg-[#090d16] p-3">
            <span className="text-slate-400 uppercase text-[10px] block">Severity</span>
            <div className="mt-1">
              <SeverityBadge severity={alert.severity} size="sm" />
            </div>
          </div>
        </div>

        {/* 3 Main Sections: Evidence, Why Detected, Suggested Mitigation */}
        <div className="space-y-4">
          {/* Evidence */}
          <div className="rounded-xl border border-slate-800 bg-[#090d16] p-4">
            <h3 className="text-xs font-mono font-bold uppercase text-slate-300 mb-2">
              Evidence
            </h3>
            <ul className="space-y-1 font-mono text-xs text-slate-300">
              <li className="flex items-center gap-2">
                <span className="text-red-400">•</span>
                <span>{alert.evidence.packetsCount.toLocaleString()} SYN packets</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-cyan-400">•</span>
                <span>{alert.evidence.responseCount} ACK responses</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-amber-400">•</span>
                <span>{alert.evidence.durationStr} duration</span>
              </li>
            </ul>
          </div>

          {/* Why was this detected? */}
          <div className="rounded-xl border border-slate-800 bg-[#090d16] p-4">
            <h3 className="text-xs font-mono font-bold uppercase text-slate-300 mb-2">
              Why was this detected?
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              {alert.aiExplanation}
            </p>
          </div>

          {/* Suggested Mitigation */}
          <div className="rounded-xl border border-slate-800 bg-[#090d16] p-4">
            <h3 className="text-xs font-mono font-bold uppercase text-slate-300 mb-2">
              Suggested Mitigation
            </h3>
            <ul className="space-y-1 text-xs text-slate-300 font-sans">
              {alert.recommendations.map((rec, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-emerald-400 font-bold">•</span>
                  <span>{rec}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between">
          <button
            onClick={handleReplayAttack}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-mono text-xs font-bold transition-all shadow-md"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Replay Attack</span>
          </button>

          <button
            onClick={() => setSelectedAlertForDetail(null)}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
