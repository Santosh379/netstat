import React, { useState } from 'react';
import { useMonitoring } from '../context/MonitoringContext';
import { SeverityBadge } from '../components/common/SeverityBadge';
import { mockAlerts } from '../data/mockData';
import type { Severity } from '../types/network';
import { 
  ShieldAlert, 
  AlertTriangle, 
  Info, 
  Search, 
  Eye
} from 'lucide-react';

export const AlertsPage: React.FC = () => {
  const { setSelectedAlertForDetail } = useMonitoring();

  const [severityFilter, setSeverityFilter] = useState<Severity | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const counts = {
    critical: 2,
    high: 5,
    medium: 7
  };

  const filteredAlerts = mockAlerts.filter((alert) => {
    if (severityFilter !== 'ALL' && alert.severity !== severityFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        alert.title.toLowerCase().includes(q) ||
        alert.sourceIp.includes(q) ||
        alert.destinationIp.includes(q) ||
        alert.attackType.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Page Title */}
      <div className="rounded-xl border border-slate-800 bg-[#0d131f] p-6 shadow-sm">
        <h2 className="text-xl font-bold font-mono text-white tracking-tight">
          Security Alerts
        </h2>
        <p className="text-xs sm:text-sm text-slate-300 font-sans mt-0.5">
          Detected suspicious network activity.
        </p>
      </div>

      {/* 3 Summary Cards: Critical 2, High 5, Medium 7 */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div
          onClick={() => setSeverityFilter(severityFilter === 'CRITICAL' ? 'ALL' : 'CRITICAL')}
          className={`cursor-pointer rounded-xl border p-4 text-center transition-all ${
            severityFilter === 'CRITICAL'
              ? 'border-red-500 bg-red-950/30'
              : 'border-red-500/30 bg-[#140b0e] hover:border-red-500/60'
          }`}
        >
          <div className="flex items-center justify-center gap-1.5 text-red-400 mb-1">
            <ShieldAlert className="w-4 h-4" />
            <span className="text-xs font-mono font-bold uppercase">Critical</span>
          </div>
          <p className="text-3xl font-bold font-mono text-white">{counts.critical}</p>
        </div>

        <div
          onClick={() => setSeverityFilter(severityFilter === 'HIGH' ? 'ALL' : 'HIGH')}
          className={`cursor-pointer rounded-xl border p-4 text-center transition-all ${
            severityFilter === 'HIGH'
              ? 'border-orange-500 bg-orange-950/30'
              : 'border-orange-500/30 bg-[#140f0b] hover:border-orange-500/60'
          }`}
        >
          <div className="flex items-center justify-center gap-1.5 text-orange-400 mb-1">
            <AlertTriangle className="w-4 h-4" />
            <span className="text-xs font-mono font-bold uppercase">High</span>
          </div>
          <p className="text-3xl font-bold font-mono text-white">{counts.high}</p>
        </div>

        <div
          onClick={() => setSeverityFilter(severityFilter === 'MEDIUM' ? 'ALL' : 'MEDIUM')}
          className={`cursor-pointer rounded-xl border p-4 text-center transition-all ${
            severityFilter === 'MEDIUM'
              ? 'border-amber-500 bg-amber-950/30'
              : 'border-amber-500/30 bg-[#14140b] hover:border-amber-500/60'
          }`}
        >
          <div className="flex items-center justify-center gap-1.5 text-amber-400 mb-1">
            <Info className="w-4 h-4" />
            <span className="text-xs font-mono font-bold uppercase">Medium</span>
          </div>
          <p className="text-3xl font-bold font-mono text-white">{counts.medium}</p>
        </div>
      </div>

      {/* Filter and Table Panel */}
      <div className="rounded-xl border border-slate-800 bg-[#0d131f] shadow-sm p-5 space-y-4">
        {/* Search */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
            <input
              type="text"
              placeholder="Filter alerts..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-lg border border-slate-800 bg-[#090d16] py-1.5 pl-8 pr-3 text-xs font-mono text-slate-200 placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
            />
          </div>

          {severityFilter !== 'ALL' && (
            <button
              onClick={() => setSeverityFilter('ALL')}
              className="text-xs font-mono text-cyan-400 hover:underline self-start sm:self-auto"
            >
              Clear filter ({severityFilter})
            </button>
          )}
        </div>

        {/* Alerts Table: Severity | Attack Type | Source IP | Destination | Time */}
        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-[11px] uppercase tracking-wider text-slate-400 bg-[#090d16]">
                <th className="py-2.5 px-4 font-semibold">Severity</th>
                <th className="py-2.5 px-4 font-semibold">Attack Type</th>
                <th className="py-2.5 px-4 font-semibold">Source IP</th>
                <th className="py-2.5 px-4 font-semibold">Destination</th>
                <th className="py-2.5 px-4 font-semibold">Time</th>
                <th className="py-2.5 px-4 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {filteredAlerts.map((alert) => (
                <tr
                  key={alert.id}
                  onClick={() => setSelectedAlertForDetail(alert)}
                  className="hover:bg-slate-800/40 cursor-pointer transition-colors"
                >
                  <td className="py-3 px-4 whitespace-nowrap">
                    <SeverityBadge severity={alert.severity} size="sm" />
                  </td>
                  <td className="py-3 px-4 font-semibold text-white whitespace-nowrap">
                    {alert.attackType}
                  </td>
                  <td className="py-3 px-4 text-cyan-300 font-semibold whitespace-nowrap">
                    {alert.sourceIp}
                  </td>
                  <td className="py-3 px-4 text-slate-300 whitespace-nowrap">
                    {alert.destinationIp}
                  </td>
                  <td className="py-3 px-4 text-slate-400 whitespace-nowrap">
                    {alert.timestamp}
                  </td>
                  <td className="py-3 px-4 text-right whitespace-nowrap">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedAlertForDetail(alert);
                      }}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-[11px] text-slate-300 transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Investigate</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
