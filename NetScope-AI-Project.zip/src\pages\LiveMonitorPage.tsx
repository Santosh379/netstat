import React from 'react';
import { useMonitoring } from '../context/MonitoringContext';
import { ProtocolBadge } from '../components/common/ProtocolBadge';
import { 
  Play, 
  Square, 
  Activity, 
  HardDrive, 
  Network
} from 'lucide-react';

export const LiveMonitorPage: React.FC = () => {
  const {
    isMonitoring,
    startCapture,
    stopCapture,
    livePackets,
    packetsPerSec,
    bytesPerSec
  } = useMonitoring();

  return (
    <div className="space-y-6">
      {/* Header and Controls */}
      <div className="rounded-xl border border-slate-800 bg-[#0d131f] p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold font-mono text-white tracking-tight">
              Live Network Monitor
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 font-sans mt-0.5">
              Monitor network packets in real time.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={startCapture}
              disabled={isMonitoring}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg font-mono text-xs font-bold transition-all ${
                isMonitoring
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 opacity-70 cursor-default'
                  : 'bg-emerald-600 hover:bg-emerald-500 text-white'
              }`}
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Start Capture</span>
            </button>

            <button
              onClick={stopCapture}
              disabled={!isMonitoring}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg font-mono text-xs font-medium border transition-colors ${
                !isMonitoring
                  ? 'bg-slate-800/40 text-slate-500 border-slate-800 cursor-not-allowed'
                  : 'bg-red-500/20 hover:bg-red-500/30 text-red-300 border-red-500/40'
              }`}
            >
              <Square className="w-3.5 h-3.5 fill-current" />
              <span>Stop</span>
            </button>
          </div>
        </div>

        {/* 3 Metrics: Packets/sec, Bytes/sec, Active Connections */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6 pt-5 border-t border-slate-800">
          <div className="rounded-lg border border-slate-800 bg-[#090d16] p-4 flex items-center gap-3">
            <div className="p-2 rounded bg-cyan-500/10 text-cyan-400">
              <Activity className="w-4 h-4" />
            </div>
            <div>
              <p className="text-[11px] font-mono uppercase text-slate-400">Packets/sec</p>
              <p className="text-xl font-bold font-mono text-white">
                {isMonitoring ? packetsPerSec.toLocaleString() : '0'}
              </p>
            </div>
          </div>

          <div className="rounded-lg border border-slate-800 bg-[#090d16] p-4 flex items-center gap-3">
            <div className="p-2 rounded bg-blue-500/10 text-blue-400">
              <HardDrive className="w-4 h-4" />
            </div>
            <div>
              <p className="text-[11px] font-mono uppercase text-slate-400">Bytes/sec</p>
              <p className="text-xl font-bold font-mono text-white">
                {isMonitoring ? bytesPerSec : '0.0 KB/s'}
              </p>
            </div>
          </div>

          <div className="rounded-lg border border-slate-800 bg-[#090d16] p-4 flex items-center gap-3">
            <div className="p-2 rounded bg-purple-500/10 text-purple-400">
              <Network className="w-4 h-4" />
            </div>
            <div>
              <p className="text-[11px] font-mono uppercase text-slate-400">Active Connections</p>
              <p className="text-xl font-bold font-mono text-white">
                {isMonitoring ? '43' : '0'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Packet Table */}
      <div className="rounded-xl border border-slate-800 bg-[#0d131f] shadow-sm overflow-hidden">
        <div className="px-5 py-3 border-b border-slate-800 bg-[#090d16] flex items-center justify-between">
          <span className="font-mono text-xs font-semibold text-slate-300 uppercase tracking-wider">
            Live Stream ({livePackets.length} captured)
          </span>
          <span className="font-mono text-[11px] text-cyan-400">
            {isMonitoring ? '● Listening' : '● Idle'}
          </span>
        </div>

        <div className="overflow-x-auto max-h-[500px] overflow-y-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead className="sticky top-0 bg-[#090d16] border-b border-slate-800">
              <tr className="text-[11px] uppercase tracking-wider text-slate-400">
                <th className="py-2.5 px-4 font-semibold">Time</th>
                <th className="py-2.5 px-4 font-semibold">Source</th>
                <th className="py-2.5 px-4 font-semibold">Destination</th>
                <th className="py-2.5 px-4 font-semibold">Protocol</th>
                <th className="py-2.5 px-4 font-semibold">Port</th>
                <th className="py-2.5 px-4 font-semibold text-right">Size</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/40">
              {livePackets.map((pkt, idx) => (
                <tr key={pkt.id + idx} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 px-4 text-slate-400 whitespace-nowrap">
                    {pkt.timestamp}
                  </td>
                  <td className="py-2.5 px-4 text-cyan-300 font-semibold whitespace-nowrap">
                    {pkt.sourceIp}
                  </td>
                  <td className="py-2.5 px-4 text-slate-300 whitespace-nowrap">
                    {pkt.destinationIp}
                  </td>
                  <td className="py-2.5 px-4 whitespace-nowrap">
                    <ProtocolBadge protocol={pkt.protocol} />
                  </td>
                  <td className="py-2.5 px-4 text-slate-300 font-semibold whitespace-nowrap">
                    {pkt.destinationPort || '-'}
                  </td>
                  <td className="py-2.5 px-4 text-right text-slate-400 whitespace-nowrap">
                    {pkt.size >= 1000 ? `${(pkt.size / 1024).toFixed(1)}KB` : `${pkt.size}B`}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
