import React, { useState } from 'react';
import { mockTopologyNodes } from '../data/mockData';
import type { TopologyNode } from '../types/network';
import { 
  Router, 
  Server, 
  Laptop, 
  ShieldAlert
} from 'lucide-react';

export const TopologyPage: React.FC = () => {
  const nodes = mockTopologyNodes;
  const [selectedNode, setSelectedNode] = useState<TopologyNode>(nodes[4]); // default Attacker .1.15

  const getNodeIcon = (role: string) => {
    switch (role) {
      case 'Router':
        return <Router className="w-6 h-6" />;
      case 'Server':
        return <Server className="w-6 h-6" />;
      case 'Attacker':
        return <ShieldAlert className="w-6 h-6" />;
      default:
        return <Laptop className="w-6 h-6" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="rounded-xl border border-slate-800 bg-[#0d131f] p-6 shadow-sm">
        <h2 className="text-xl font-bold font-mono text-white tracking-tight">
          Network Topology
        </h2>
        <p className="text-xs sm:text-sm text-slate-300 font-sans mt-0.5">
          Visual map of network hosts, server, and detected attacker. Click any node to view details.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* SVG Network Graph */}
        <div className="lg:col-span-2 rounded-xl border border-slate-800 bg-[#090d16] p-4 shadow-sm flex flex-col items-center justify-center relative min-h-[480px]">
          <svg className="w-full h-full min-h-[440px]" viewBox="0 0 800 480">
            {/* Connecting lines from Router (400, 70) to PC-01 (200, 220), Server (400, 220), PC-02 (600, 220) */}
            <line x1="400" y1="70" x2="400" y2="140" stroke="#334155" strokeWidth="2" />
            <line x1="200" y1="140" x2="600" y2="140" stroke="#334155" strokeWidth="2" />
            
            {/* Drops to nodes */}
            <line x1="200" y1="140" x2="200" y2="220" stroke="#334155" strokeWidth="2" />
            <line x1="400" y1="140" x2="400" y2="220" stroke="#334155" strokeWidth="2" />
            <line x1="600" y1="140" x2="600" y2="220" stroke="#334155" strokeWidth="2" />

            {/* Attack line from Attacker (400, 390) up to Server (400, 220) */}
            <line 
              x1="400" 
              y1="390" 
              x2="400" 
              y2="220" 
              stroke="#ef4444" 
              strokeWidth="2.5" 
              strokeDasharray="6 4" 
              className="animate-pulse"
            />

            {/* Traveling red packet circle on attack line */}
            <circle r="4" fill="#ef4444">
              <animateMotion
                path="M 400 390 L 400 220"
                dur="1.8s"
                repeatCount="indefinite"
              />
            </circle>

            {/* Render Nodes */}
            {/* 1. Router */}
            <g 
              transform="translate(400, 70)" 
              className="cursor-pointer"
              onClick={() => setSelectedNode(nodes[0])}
            >
              <circle 
                r="30" 
                fill="#0b172a" 
                stroke={selectedNode.id === 'node-router' ? '#06b6d4' : '#1e293b'} 
                strokeWidth={selectedNode.id === 'node-router' ? 3 : 2} 
              />
              <foreignObject x="-12" y="-12" width="24" height="24">
                <div className="text-cyan-400 flex items-center justify-center">
                  <Router className="w-6 h-6" />
                </div>
              </foreignObject>
              <text y="46" textAnchor="middle" className="font-mono text-xs font-bold fill-white">Router</text>
              <text y="60" textAnchor="middle" className="font-mono text-[11px] fill-slate-400">192.168.1.1</text>
            </g>

            {/* 2. PC-01 */}
            <g 
              transform="translate(200, 220)" 
              className="cursor-pointer"
              onClick={() => setSelectedNode(nodes[1])}
            >
              <circle 
                r="28" 
                fill="#0b172a" 
                stroke={selectedNode.id === 'node-pc01' ? '#06b6d4' : '#1e293b'} 
                strokeWidth={selectedNode.id === 'node-pc01' ? 3 : 2} 
              />
              <foreignObject x="-12" y="-12" width="24" height="24">
                <div className="text-blue-400 flex items-center justify-center">
                  <Laptop className="w-6 h-6" />
                </div>
              </foreignObject>
              <text y="44" textAnchor="middle" className="font-mono text-xs font-bold fill-white">PC-01</text>
              <text y="58" textAnchor="middle" className="font-mono text-[11px] fill-slate-400">.1.10</text>
            </g>

            {/* 3. Server (Target) */}
            <g 
              transform="translate(400, 220)" 
              className="cursor-pointer"
              onClick={() => setSelectedNode(nodes[2])}
            >
              <circle 
                r="32" 
                fill="#16120b" 
                stroke={selectedNode.id === 'node-server' ? '#06b6d4' : '#f59e0b'} 
                strokeWidth={selectedNode.id === 'node-server' ? 3 : 2} 
              />
              <foreignObject x="-12" y="-12" width="24" height="24">
                <div className="text-amber-400 flex items-center justify-center">
                  <Server className="w-6 h-6" />
                </div>
              </foreignObject>
              <text y="48" textAnchor="middle" className="font-mono text-xs font-bold fill-white">Server (Target)</text>
              <text y="62" textAnchor="middle" className="font-mono text-[11px] fill-amber-400 font-semibold">.1.20</text>
            </g>

            {/* 4. PC-02 */}
            <g 
              transform="translate(600, 220)" 
              className="cursor-pointer"
              onClick={() => setSelectedNode(nodes[3])}
            >
              <circle 
                r="28" 
                fill="#0b172a" 
                stroke={selectedNode.id === 'node-pc02' ? '#06b6d4' : '#1e293b'} 
                strokeWidth={selectedNode.id === 'node-pc02' ? 3 : 2} 
              />
              <foreignObject x="-12" y="-12" width="24" height="24">
                <div className="text-blue-400 flex items-center justify-center">
                  <Laptop className="w-6 h-6" />
                </div>
              </foreignObject>
              <text y="44" textAnchor="middle" className="font-mono text-xs font-bold fill-white">PC-02</text>
              <text y="58" textAnchor="middle" className="font-mono text-[11px] fill-slate-400">.1.30</text>
            </g>

            {/* 5. Attacker */}
            <g 
              transform="translate(400, 390)" 
              className="cursor-pointer"
              onClick={() => setSelectedNode(nodes[4])}
            >
              <circle 
                r="30" 
                fill="#200a0d" 
                stroke={selectedNode.id === 'node-attacker' ? '#06b6d4' : '#ef4444'} 
                strokeWidth={selectedNode.id === 'node-attacker' ? 3 : 2} 
                className="animate-pulse"
              />
              <foreignObject x="-12" y="-12" width="24" height="24">
                <div className="text-red-400 flex items-center justify-center">
                  <ShieldAlert className="w-6 h-6" />
                </div>
              </foreignObject>
              <text y="46" textAnchor="middle" className="font-mono text-xs font-bold fill-red-400">Attacker</text>
              <text y="60" textAnchor="middle" className="font-mono text-[11px] fill-red-400 font-semibold">.1.15</text>
            </g>
          </svg>

          {/* Simple Legend */}
          <div className="absolute bottom-3 left-4 flex items-center gap-4 text-xs font-mono text-slate-400 bg-[#0d131f]/90 p-2 rounded-lg border border-slate-800">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-400" /> Normal
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400" /> Target
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-red-400" /> Attacker
            </span>
          </div>
        </div>

        {/* Node Information Card: IP Address, Packets, Connections, Alerts, Status */}
        <div className="rounded-xl border border-slate-800 bg-[#0d131f] p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className={`p-2 rounded-lg ${
                selectedNode.role === 'Attacker' ? 'bg-red-500/10 text-red-400 border border-red-500/20' : 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
              }`}>
                {getNodeIcon(selectedNode.role)}
              </div>
              <div>
                <h3 className="font-mono text-sm font-bold text-white">
                  {selectedNode.hostname}
                </h3>
                <span className="text-xs font-mono text-cyan-400">{selectedNode.ip}</span>
              </div>
            </div>

            <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
              selectedNode.status === 'Compromised' || selectedNode.status === 'Critical'
                ? 'bg-red-500/20 text-red-300'
                : 'bg-emerald-500/20 text-emerald-300'
            }`}>
              {selectedNode.status}
            </span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">IP Address</span>
              <span className="text-white font-semibold">{selectedNode.ip}</span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Packets</span>
              <span className="text-slate-200">
                {(selectedNode.packetsIn + selectedNode.packetsOut).toLocaleString()}
              </span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Connections</span>
              <span className="text-slate-200">
                {selectedNode.role === 'Server' ? '24 Active' : selectedNode.role === 'Attacker' ? '18 Probes' : '4 Active'}
              </span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Alerts</span>
              <span className={selectedNode.alertsCount > 0 ? 'text-red-400 font-bold' : 'text-emerald-400'}>
                {selectedNode.alertsCount}
              </span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-800/60">
              <span className="text-slate-400">Status</span>
              <span className={selectedNode.role === 'Attacker' ? 'text-red-400 font-bold' : 'text-emerald-400 font-semibold'}>
                {selectedNode.role === 'Attacker' ? 'Flagged Malicious' : 'Online / Verified'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
