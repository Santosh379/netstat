import { mockLivePackets } from '../data/mockData';
import type { LivePacket } from '../types/network';

/**
 * Service placeholder for NetScope AI Packet Capture & PCAP Parsing API
 * Future integration with: Scapy / PyShark / Libpcap background daemon
 */

export interface CaptureStats {
  interfaceName: string;
  ipAddress: string;
  packetsPerSec: number;
  bytesPerSec: string;
  totalPackets: number;
  droppedPackets: number;
  promiscuousMode: boolean;
}

export interface PcapAnalysisResult {
  filename: string;
  filesize: string;
  packetsAnalyzed: number;
  uniqueHosts: number;
  tcpConnections: number;
  potentialThreats: number;
  durationSeconds: number;
  topProtocols: { name: string; percentage: number }[];
  detectedSignatures: { signature: string; severity: string; count: number }[];
}

export const packetsApi = {
  getInitialPackets(): LivePacket[] {
    return [...mockLivePackets];
  },

  generateRandomPacket(): LivePacket {
    const protocols: Array<'TCP' | 'UDP' | 'ICMP' | 'ARP' | 'DNS' | 'TLS'> = [
      'TCP', 'TCP', 'UDP', 'DNS', 'TLS', 'TCP', 'ICMP', 'ARP'
    ];
    const protocol = protocols[Math.floor(Math.random() * protocols.length)];
    const ipPool = [
      '192.168.1.15',
      '192.168.1.20',
      '192.168.1.10',
      '192.168.1.1',
      '192.168.1.30',
      '192.168.1.5',
      '10.0.0.24',
      '172.16.4.12'
    ];
    const src = ipPool[Math.floor(Math.random() * ipPool.length)];
    let dst = ipPool[Math.floor(Math.random() * ipPool.length)];
    while (dst === src) {
      dst = ipPool[Math.floor(Math.random() * ipPool.length)];
    }

    const srcPort = Math.floor(Math.random() * 20000 + 40000);
    const commonPorts = [80, 443, 22, 53, 8080, 3306, 21, 8883];
    const dstPort = commonPorts[Math.floor(Math.random() * commonPorts.length)];

    const now = new Date();
    const timeStr = `${now.toTimeString().split(' ')[0]}.${String(now.getMilliseconds()).padStart(3, '0')}`;
    const isAttacker = src === '192.168.1.15';

    const flags = protocol === 'TCP' ? (isAttacker ? ['SYN'] : ['ACK', 'PSH']) : [];
    const size = Math.floor(Math.random() * 1200 + 54);

    return {
      id: `PKT-${Date.now().toString().slice(-6)}`,
      timestamp: timeStr,
      sourceIp: src,
      destinationIp: dst,
      protocol,
      sourcePort: srcPort,
      destinationPort: dstPort,
      size,
      flags,
      info: isAttacker
        ? `${srcPort} → ${dstPort} [SYN] Seq=${Math.floor(Math.random() * 90000000)} Win=1024 Len=0`
        : `${srcPort} → ${dstPort} ${protocol} Flow Data [Len=${size}]`,
      isSuspicious: isAttacker,
      hexPreview: '45 00 00 3c ' + Array.from({ length: 16 }, () => Math.floor(Math.random() * 256).toString(16).padStart(2, '0')).join(' ')
    };
  },

  async analyzePcapFile(
    file: { name: string; size: number },
    onProgress: (percent: number, step: string) => void
  ): Promise<PcapAnalysisResult> {
    const steps = [
      { p: 15, text: 'Reading PCAP header & frame link layers...' },
      { p: 40, text: 'Reconstructing TCP streams & reassembling IP fragments...' },
      { p: 78, text: 'Extracting packet features & computing entropy...' },
      { p: 92, text: 'Evaluating behavioral signatures against attack catalog...' },
      { p: 100, text: 'Analysis Complete' }
    ];

    for (const step of steps) {
      await new Promise((r) => setTimeout(r, 450));
      onProgress(step.p, step.text);
    }

    return {
      filename: file.name,
      filesize: (file.size / (1024 * 1024)).toFixed(2) + ' MB',
      packetsAnalyzed: 24892,
      uniqueHosts: 18,
      tcpConnections: 2341,
      potentialThreats: 7,
      durationSeconds: 142.6,
      topProtocols: [
        { name: 'TCP', percentage: 64 },
        { name: 'UDP', percentage: 22 },
        { name: 'ICMP', percentage: 8 },
        { name: 'ARP', percentage: 4 },
        { name: 'DNS', percentage: 2 }
      ],
      detectedSignatures: [
        { signature: 'TCP SYN Flood Attack (RFC 4987)', severity: 'CRITICAL', count: 4832 },
        { signature: 'Horizontal TCP Port Sweep', severity: 'HIGH', count: 18 },
        { signature: 'Gratuitous ARP Cache Poisoning', severity: 'CRITICAL', count: 380 },
        { signature: 'SSH Brute Force Handshake Spray', severity: 'MEDIUM', count: 64 }
      ]
    };
  }
};
