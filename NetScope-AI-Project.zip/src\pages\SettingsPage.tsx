import React, { useState } from 'react';
import { Settings, Check } from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const [interfaceName, setInterfaceName] = useState('Wi-Fi');
  const [packetCapture, setPacketCapture] = useState(true);
  const [darkMode, setDarkMode] = useState(true);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-6 max-w-xl">
      {/* Header */}
      <div className="rounded-xl border border-slate-800 bg-[#0d131f] p-6 shadow-sm">
        <div className="flex items-center gap-2.5">
          <Settings className="w-5 h-5 text-cyan-400" />
          <h2 className="text-xl font-bold font-mono text-white tracking-tight">
            Settings
          </h2>
        </div>
        <p className="text-xs sm:text-sm text-slate-300 font-sans mt-0.5">
          Configure network interface and monitoring options.
        </p>
      </div>

      {/* Minimal Settings Card */}
      <div className="rounded-xl border border-slate-800 bg-[#0d131f] p-6 shadow-sm space-y-5 font-mono text-xs">
        {/* Monitoring Interface */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <p className="font-bold text-white">Monitoring Interface</p>
            <p className="text-[11px] text-slate-400 font-sans">Active network capture adapter</p>
          </div>
          <select
            value={interfaceName}
            onChange={(e) => setInterfaceName(e.target.value)}
            className="rounded-lg border border-slate-800 bg-[#090d16] px-3 py-1.5 text-slate-200 outline-none focus:border-cyan-500"
          >
            <option value="Wi-Fi">Wi-Fi</option>
            <option value="Ethernet">Ethernet</option>
            <option value="Loopback">Loopback</option>
          </select>
        </div>

        {/* Packet Capture Toggle */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <p className="font-bold text-white">Packet Capture</p>
            <p className="text-[11px] text-slate-400 font-sans">Enable or disable packet sniffing</p>
          </div>
          <button
            onClick={() => setPacketCapture(!packetCapture)}
            className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
              packetCapture
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : 'bg-slate-800 text-slate-400 border border-slate-700'
            }`}
          >
            {packetCapture ? '[ Enabled ]' : '[ Disabled ]'}
          </button>
        </div>

        {/* Dark Mode Toggle */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <p className="font-bold text-white">Dark Mode</p>
            <p className="text-[11px] text-slate-400 font-sans">Cybersecurity dark theme</p>
          </div>
          <button
            onClick={() => setDarkMode(!darkMode)}
            className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
              darkMode
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                : 'bg-slate-800 text-slate-400 border border-slate-700'
            }`}
          >
            {darkMode ? '[ Enabled ]' : '[ Disabled ]'}
          </button>
        </div>

        {/* Save Button */}
        <div className="pt-2 flex items-center justify-between">
          {saved && (
            <span className="text-emerald-400 flex items-center gap-1.5 text-xs">
              <Check className="w-4 h-4" /> Settings updated
            </span>
          )}
          <div className="ml-auto">
            <button
              onClick={handleSave}
              className="px-5 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold transition-colors shadow-md"
            >
              Save Settings
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
