import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  RotateCcw, 
  Server, 
  Laptop, 
  Flame,
  ArrowDown
} from 'lucide-react';

interface TimelineStep {
  id: number;
  time: string;
  source: string;
  target: string;
  port: number;
  service: string;
  flag: string;
  result: string;
}

export const AttackReplayPage: React.FC = () => {
  const steps: TimelineStep[] = [
    { id: 1, time: '10:42:01.002', source: '192.168.1.15', target: 'Server', port: 22, service: 'SSH', flag: 'SYN', result: 'Open' },
    { id: 2, time: '10:42:01.114', source: '192.168.1.15', target: 'Server', port: 23, service: 'Telnet', flag: 'SYN', result: 'Filtered' },
    { id: 3, time: '10:42:01.227', source: '192.168.1.15', target: 'Server', port: 80, service: 'HTTP', flag: 'SYN', result: 'Open' },
    { id: 4, time: '10:42:01.341', source: '192.168.1.15', target: 'Server', port: 443, service: 'HTTPS', flag: 'SYN', result: 'Open' },
    { id: 5, time: '10:42:01.455', source: '192.168.1.15', target: 'Server', port: 3306, service: 'MySQL', flag: 'SYN', result: 'Filtered' },
    { id: 6, time: '10:42:01.568', source: '192.168.1.15', target: 'Server', port: 8080, service: 'Dev-API', flag: 'SYN', result: 'Open' }
  ];

  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isFast, setIsFast] = useState<boolean>(false);

  const currentStep = steps[currentStepIndex];

  // Auto-play interval
  useEffect(() => {
    let timer: any = null;
    if (isPlaying) {
      const delay = isFast ? 500 : 1000;
      timer = setInterval(() => {
        setCurrentStepIndex((prev) => {
          if (prev >= steps.length - 1) {
            setIsPlaying(false);
            return prev;
          }
          return prev + 1;
        });
      }, delay);
    }
    return () => clearInterval(timer);
  }, [isPlaying, isFast, steps.length]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="rounded-xl border border-slate-800 bg-[#0d131f] p-6 shadow-sm">
        <div className="flex items-center gap-2.5">
          <Flame className="w-5 h-5 text-red-400" />
          <h2 className="text-xl font-bold font-mono text-white tracking-tight">
            Attack Replay
          </h2>
        </div>
        <p className="text-xs sm:text-sm text-slate-300 font-sans mt-0.5">
          Replay the packet sequence that triggered an alert.
        </p>

        {/* Attack Scope Summary */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-5 pt-4 border-t border-slate-800 font-mono text-xs">
          <div className="bg-[#090d16] p-3 rounded-lg border border-slate-800">
            <span className="text-slate-400 uppercase text-[10px] block">Attack Type</span>
            <span className="text-red-400 font-bold text-sm mt-0.5 block">PORT SCAN</span>
          </div>

          <div className="bg-[#090d16] p-3 rounded-lg border border-slate-800">
            <span className="text-slate-400 uppercase text-[10px] block">Source</span>
            <span className="text-cyan-300 font-bold text-sm mt-0.5 block">192.168.1.15</span>
          </div>

          <div className="bg-[#090d16] p-3 rounded-lg border border-slate-800">
            <span className="text-slate-400 uppercase text-[10px] block">Target</span>
            <span className="text-blue-300 font-bold text-sm mt-0.5 block">192.168.1.20</span>
          </div>
        </div>
      </div>

      {/* Visual Animated Packet Transmission Box */}
      <div className="rounded-xl border border-slate-800 bg-[#0d131f] p-6 shadow-sm overflow-hidden">
        <div className="flex items-center justify-between max-w-xl mx-auto py-4">
          {/* Source Node */}
          <div className="flex flex-col items-center">
            <div className="w-14 h-14 rounded-xl bg-red-950/40 border border-red-500/40 flex items-center justify-center text-red-400 mb-2 shadow-md">
              <Laptop className="w-7 h-7" />
            </div>
            <span className="font-mono text-xs font-bold text-white">192.168.1.15</span>
            <span className="text-[10px] font-mono text-red-400">Attacker</span>
          </div>

          {/* Wire Track with Animated Packet */}
          <div className="flex-1 px-6">
            <div className="relative py-4">
              <div className="h-1 w-full bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-cyan-400 transition-all duration-300"
                  style={{ width: `${((currentStepIndex + 1) / steps.length) * 100}%` }}
                />
              </div>

              {/* Animated Packet Marker */}
              <div 
                className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 transition-all duration-300"
                style={{ left: `${((currentStepIndex + 0.5) / steps.length) * 100}%` }}
              >
                <div className="px-2.5 py-1 rounded bg-cyan-500 text-slate-950 font-mono text-[10px] font-bold shadow-lg shadow-cyan-500/30 whitespace-nowrap">
                  {currentStep.flag} → :{currentStep.port}
                </div>
              </div>
            </div>

            <p className="text-center font-mono text-xs text-slate-300 mt-2">
              Probing port <span className="text-cyan-400 font-bold">:{currentStep.port} ({currentStep.service})</span> &bull; Status: <span className="text-emerald-400 font-bold">{currentStep.result}</span>
            </p>
          </div>

          {/* Target Node */}
          <div className="flex flex-col items-center">
            <div className="w-14 h-14 rounded-xl bg-cyan-950/40 border border-cyan-500/40 flex items-center justify-center text-cyan-400 mb-2 shadow-md">
              <Server className="w-7 h-7" />
            </div>
            <span className="font-mono text-xs font-bold text-white">192.168.1.20</span>
            <span className="text-[10px] font-mono text-cyan-400">Server</span>
          </div>
        </div>
      </div>

      {/* Visual Sequence Timeline Cards */}
      <div className="rounded-xl border border-slate-800 bg-[#0d131f] p-5 shadow-sm space-y-4">
        <h3 className="font-mono text-xs font-bold uppercase tracking-wider text-slate-400">
          Packet Transmission Timeline
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {steps.map((st, idx) => {
            const isActive = idx === currentStepIndex;
            return (
              <div
                key={st.id}
                onClick={() => {
                  setCurrentStepIndex(idx);
                  setIsPlaying(false);
                }}
                className={`p-4 rounded-xl border transition-all cursor-pointer font-mono text-xs ${
                  isActive
                    ? 'border-cyan-500 bg-cyan-950/20 ring-1 ring-cyan-500/50'
                    : 'border-slate-800 bg-[#090d16] hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between text-slate-400 text-[11px] mb-2 pb-1.5 border-b border-slate-800">
                  <span>{st.time}</span>
                  <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                    st.result === 'Open' ? 'text-emerald-400 bg-emerald-950/40' : 'text-slate-400 bg-slate-800'
                  }`}>
                    {st.result}
                  </span>
                </div>

                <div className="space-y-1 text-center py-1">
                  <p className="text-slate-300 font-semibold">{st.source}</p>
                  <div className="flex flex-col items-center justify-center text-cyan-400 text-[10px]">
                    <span className="border-l border-cyan-500/50 h-3" />
                    <span className="bg-[#0d131f] px-2 py-0.5 rounded border border-slate-800 my-0.5 text-amber-300 font-bold">
                      {st.flag}
                    </span>
                    <ArrowDown className="w-3.5 h-3.5" />
                  </div>
                  <p className="text-white font-bold">Server :{st.port} ({st.service})</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Bottom Controls Bar: [ ◀ ] [ ▶ PLAY ] [ ⏸ ] [ ▶▶ ] and Slider */}
      <div className="rounded-xl border border-slate-800 bg-[#0d131f] p-5 shadow-sm space-y-4">
        {/* Timeline Slider */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span>Timeline Progress</span>
            <span>Step {currentStepIndex + 1} of {steps.length}</span>
          </div>

          <div className="relative py-2">
            <input
              type="range"
              min={0}
              max={steps.length - 1}
              value={currentStepIndex}
              onChange={(e) => {
                setCurrentStepIndex(Number(e.target.value));
                setIsPlaying(false);
              }}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
            />
          </div>
        </div>

        {/* Playback Buttons */}
        <div className="flex items-center justify-between pt-2">
          <div className="flex items-center gap-2">
            {/* Step Back [ ◀ ] */}
            <button
              onClick={() => setCurrentStepIndex((prev) => Math.max(0, prev - 1))}
              disabled={currentStepIndex === 0}
              className="p-2 rounded-lg border border-slate-800 bg-[#090d16] hover:bg-slate-800 text-slate-300 disabled:opacity-30 transition-colors"
              title="Step Back"
            >
              <SkipBack className="w-4 h-4" />
            </button>

            {/* Play / Pause [ ▶ PLAY ] [ ⏸ ] */}
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="inline-flex items-center gap-2 px-5 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-mono text-xs font-bold transition-all shadow-md"
            >
              {isPlaying ? (
                <>
                  <Pause className="w-4 h-4 fill-slate-950" />
                  <span>PAUSE</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-slate-950" />
                  <span>PLAY</span>
                </>
              )}
            </button>

            {/* Step Forward [ ▶▶ ] */}
            <button
              onClick={() => setCurrentStepIndex((prev) => Math.min(steps.length - 1, prev + 1))}
              disabled={currentStepIndex === steps.length - 1}
              className="p-2 rounded-lg border border-slate-800 bg-[#090d16] hover:bg-slate-800 text-slate-300 disabled:opacity-30 transition-colors"
              title="Step Forward"
            >
              <SkipForward className="w-4 h-4" />
            </button>

            {/* Fast Forward [ ▶▶ ] */}
            <button
              onClick={() => setIsFast(!isFast)}
              className={`px-3 py-2 rounded-lg border font-mono text-xs font-bold transition-colors ${
                isFast 
                  ? 'border-cyan-500 bg-cyan-500/20 text-cyan-300' 
                  : 'border-slate-800 bg-[#090d16] text-slate-400 hover:text-white'
              }`}
              title="Toggle Speed"
            >
              2x Speed
            </button>

            {/* Reset */}
            <button
              onClick={() => {
                setCurrentStepIndex(0);
                setIsPlaying(false);
              }}
              className="p-2 rounded-lg border border-slate-800 bg-[#090d16] hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
              title="Reset"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>

          <div className="text-xs font-mono text-slate-400">
            Current: <span className="text-cyan-400 font-bold">{currentStep.time}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
