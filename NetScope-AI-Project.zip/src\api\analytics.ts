import { 
  mockTrafficTimeline, 
  mockProtocolDistribution 
} from '../data/mockData';

export const analyticsApi = {
  async getTrafficTimeline(timeRange: '1H' | '6H' | '24H' = '1H') {
    await new Promise((r) => setTimeout(r, 60));
    return mockTrafficTimeline[timeRange] || mockTrafficTimeline['1H'];
  },

  async getProtocolDistribution() {
    await new Promise((r) => setTimeout(r, 50));
    return mockProtocolDistribution;
  }
};
