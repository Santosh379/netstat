import React, { createContext, useContext, useState, useEffect } from 'react';
import type { ReactNode } from 'react';
import type { LivePacket, SecurityAlert } from '../types/network';
import { packetsApi } from '../api/packets';

export interface ToastMessage {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'danger';
}

interface MonitoringContextType {
  isMonitoring: boolean;
  toggleMonitoring: () => void;
  startCapture: () => void;
  stopCapture: () => void;
  clearPackets: () => void;
  livePackets: LivePacket[];
  packetsPerSec: number;
  bytesPerSec: string;
  totalPacketsCount: number;
  activeHostsCount: number;
  threatsCount: number;
  threatScore: number;
  selectedAlertForDetail: SecurityAlert | null;
  setSelectedAlertForDetail: (alert: SecurityAlert | null) => void;
  toasts: ToastMessage[];
  addToast: (title: string, message: string, type?: 'info' | 'success' | 'warning' | 'danger') => void;
  removeToast: (id: string) => void;
  activeInterface: string;
  setActiveInterface: (iface: string) => void;
}

const MonitoringContext = createContext<MonitoringContextType | undefined>(undefined);

export const MonitoringProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isMonitoring, setIsMonitoring] = useState<boolean>(true);
  const [livePackets, setLivePackets] = useState<LivePacket[]>(() => packetsApi.getInitialPackets());
  const [packetsPerSec, setPacketsPerSec] = useState<number>(1284);
  const [bytesPerSec, setBytesPerSec] = useState<string>('4.2 MB/s');
  const [totalPacketsCount, setTotalPacketsCount] = useState<number>(12842);
  const [activeHostsCount] = useState<number>(27);
  const [threatsCount] = useState<number>(14);
  const [threatScore] = useState<number>(72);
  const [selectedAlertForDetail, setSelectedAlertForDetail] = useState<SecurityAlert | null>(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [activeInterface, setActiveInterface] = useState<string>('Wi-Fi (wlan0 - 192.168.1.10)');

  const addToast = (
    title: string,
    message: string,
    type: 'info' | 'success' | 'warning' | 'danger' = 'info'
  ) => {
    const id = `${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    setToasts((prev) => [...prev, { id, title, message, type }]);

    setTimeout(() => {
      removeToast(id);
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const toggleMonitoring = () => {
    if (isMonitoring) {
      setIsMonitoring(false);
      addToast('Monitoring Paused', 'Packet capture buffer preserved.', 'warning');
    } else {
      setIsMonitoring(true);
      addToast('Monitoring Started', `Listening on interface ${activeInterface}`, 'success');
    }
  };

  const startCapture = () => {
    if (!isMonitoring) {
      setIsMonitoring(true);
      addToast('Capture Active', 'Real-time packet inspection engaged.', 'success');
    }
  };

  const stopCapture = () => {
    if (isMonitoring) {
      setIsMonitoring(false);
      addToast('Capture Halted', 'Packet stream ingestion stopped.', 'info');
    }
  };

  const clearPackets = () => {
    setLivePackets([]);
    addToast('Buffer Cleared', 'Live packet observation table reset.', 'info');
  };

  // Realistic packet generator interval when monitoring is active
  useEffect(() => {
    if (!isMonitoring) {
      setPacketsPerSec(0);
      setBytesPerSec('0.0 KB/s');
      return;
    }

    const interval = setInterval(() => {
      const newPkt = packetsApi.generateRandomPacket();
      setLivePackets((prev) => [newPkt, ...prev.slice(0, 79)]);
      setTotalPacketsCount((prev) => prev + 1);

      // Fluctuate rate realistically
      const jitter = Math.floor(Math.random() * 80 - 40);
      const currentRate = Math.max(1150, Math.min(1450, 1284 + jitter));
      setPacketsPerSec(currentRate);

      const mbRate = ((currentRate * 3.4) / 1024).toFixed(1);
      setBytesPerSec(`${mbRate} MB/s`);
    }, 850);

    return () => clearInterval(interval);
  }, [isMonitoring]);

  return (
    <MonitoringContext.Provider
      value={{
        isMonitoring,
        toggleMonitoring,
        startCapture,
        stopCapture,
        clearPackets,
        livePackets,
        packetsPerSec,
        bytesPerSec,
        totalPacketsCount,
        activeHostsCount,
        threatsCount,
        threatScore,
        selectedAlertForDetail,
        setSelectedAlertForDetail,
        toasts,
        addToast,
        removeToast,
        activeInterface,
        setActiveInterface
      }}
    >
      {children}
    </MonitoringContext.Provider>
  );
};

export const useMonitoring = () => {
  const context = useContext(MonitoringContext);
  if (!context) {
    throw new Error('useMonitoring must be used within a MonitoringProvider');
  }
  return context;
};
