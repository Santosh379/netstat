# NetScope AI — Network Security & Threat Monitoring Platform

> **Detect. Analyze. Replay.**

NetScope AI is a cybersecurity network monitoring dashboard designed for Security Operations Centers (SOCs) and network administrators.

---

## 🚀 Quick Start (For Friends)

### Option 1: 1-Click Launch (Windows)
Double-click **`run.bat`** in this folder! It will automatically start the server and open the dashboard in your default web browser.

---

### Option 2: Run via Terminal (Any OS: Windows / macOS / Linux)

#### Method A: Run Pre-built Production Build (Fastest - No installation required)
If you have Node.js installed, open terminal in this folder and run:
```bash
npx serve dist -p 5173
```
Then open [http://localhost:5173](http://localhost:5173) in your browser.

#### Method B: Development Mode
```bash
# 1. Install dependencies
npm install

# 2. Start the dev server
npm run dev
```
Then open the local URL shown in terminal (usually `http://localhost:5173`).

---

## 🌟 Key Features & Pages

1. **Dashboard (`/`)**:
   - Live KPI metric cards (Total Packets, Active Hosts, Threats Detected, Threat Score).
   - Real-time Traffic Overview line/area chart (1H, 6H, 24H, 7D).
   - Protocol Distribution donut chart (TCP 61%, UDP 24%, ICMP 9%, ARP 4%, Other 2%).
   - Recent Security Alerts table with 1-click investigation drawer.

2. **Live Packet Monitor (`/live`)**:
   - Streaming packet observation buffer with dynamic rate indicators.
   - Filtering by Protocol (TCP, UDP, ICMP, ARP, DNS, TLS) or search query.
   - Packet header disassembly & raw L2/L3/L4 Hex dump viewer.

3. **PCAP Analyzer (`/pcap`)**:
   - Drag-and-drop packet capture tracefile (.pcap, .pcapng) analyzer.
   - Quick Test sample buttons (`sample_syn_flood.pcap`, `sample_portscan.pcap`).
   - 5-stage feature extraction progress bar & threat signature breakdown.

4. **Alerts & SOC Triage (`/alerts`)**:
   - Threat summary cards (Critical, High, Medium, Low).
   - Filterable alert queue.
   - AI Reasoning Engine explaining attack signatures & MITRE tactics.
   - Actionable remediation checklists and 1-click IP quarantine.

5. **Attack Replay (`/replay`)**:
   - Visual packet movement animation across the wire from Attacker to Target.
   - Interactive timeline scrubber slider with step-by-step playback controls (Play, Pause, Step, 1x/2x speed).
   - Multiple pre-loaded attack scenarios: *Stealth SYN Port Sweep*, *High-Volume SYN Flood*, *SSH Brute Force*.

6. **Network Topology (`/topology`)**:
   - Interactive SVG topological map showing Gateway, Server, Laptop, Attacker, and IoT camera.
   - Animated packet pulses traveling across links and red hostile vectors.
   - Endpoint inspector drawer and 802.1X switch port isolation simulation.

7. **Analytics (`/analytics`)**:
   - Attack signature bar charts, longitudinal anomaly spikes, and top talkers bandwidth ranking.

8. **Security Reports (`/reports`)**:
   - Executive Incident Summaries, compliance records, report generator modal, and JSON export.

---

## 🛠 Tech Stack

- **Framework**: React 19 + TypeScript + Vite
- **Styling**: Tailwind CSS v4 (Cybersecurity Dark Theme)
- **Charts**: Recharts
- **Icons**: Lucide React
- **Routing**: React Router v7
- **State**: Custom React Monitoring Context with realistic simulation engine
