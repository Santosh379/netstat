import { mockAlerts } from '../data/mockData';
import type { SecurityAlert, AlertStatus, Severity, AttackType } from '../types/network';

/**
 * Service placeholder for NetScope AI Alerts API
 * In future iterations, these functions will connect to:
 * FastAPI backend -> PostgreSQL / Scapy Detection Engine
 */

export const alertsApi = {
  async getAlerts(filters?: {
    severity?: Severity | 'ALL';
    attackType?: AttackType | 'ALL';
    status?: AlertStatus | 'ALL';
    search?: string;
  }): Promise<SecurityAlert[]> {
    // Simulated network delay
    await new Promise((resolve) => setTimeout(resolve, 80));

    let results = [...mockAlerts];

    if (filters) {
      if (filters.severity && filters.severity !== 'ALL') {
        results = results.filter((a) => a.severity === filters.severity);
      }
      if (filters.attackType && filters.attackType !== 'ALL') {
        results = results.filter((a) => a.attackType === filters.attackType);
      }
      if (filters.status && filters.status !== 'ALL') {
        results = results.filter((a) => a.status === filters.status);
      }
      if (filters.search) {
        const query = filters.search.toLowerCase();
        results = results.filter(
          (a) =>
            a.title.toLowerCase().includes(query) ||
            a.sourceIp.includes(query) ||
            a.destinationIp.includes(query) ||
            a.attackType.toLowerCase().includes(query)
        );
      }
    }

    return results;
  },

  async getAlertById(id: string): Promise<SecurityAlert | undefined> {
    await new Promise((resolve) => setTimeout(resolve, 50));
    return mockAlerts.find((a) => a.id === id);
  },

  async updateAlertStatus(id: string, status: AlertStatus): Promise<boolean> {
    await new Promise((resolve) => setTimeout(resolve, 100));
    const alert = mockAlerts.find((a) => a.id === id);
    if (alert) {
      alert.status = status;
      return true;
    }
    return false;
  },

  async blockIp(ipAddress: string): Promise<{ success: boolean; ruleId: string }> {
    // Future integration with iptables / nftables via FastAPI
    await new Promise((resolve) => setTimeout(resolve, 300));
    return {
      success: Boolean(ipAddress),
      ruleId: `FW-BLOCK-${Math.floor(Math.random() * 90000 + 10000)}`
    };
  }
};

