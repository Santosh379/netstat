import React, { useState, useRef } from 'react';
import { 
  FolderArchive, 
  CheckCircle2, 
  RotateCcw,
  Sparkles
} from 'lucide-react';

export const PcapAnalyzerPage: React.FC = () => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isDragging, setIsDragging] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [progressStep, setProgressStep] = useState('');
  const [analysisDone, setAnalysisDone] = useState(false);

  const startAnalysis = async () => {
    setAnalyzing(true);
    setAnalysisDone(false);
    setProgress(0);
    setProgressStep('Reading packet capture header...');

    const stages = [
      { p: 25, msg: 'Reading packet capture header...' },
      { p: 52, msg: 'Rebuilding TCP streams...' },
      { p: 72, msg: 'Extracting packet features...' },
      { p: 90, msg: 'Detecting attack signatures...' },
      { p: 100, msg: 'Analysis Complete' }
    ];

    for (const stage of stages) {
      await new Promise((r) => setTimeout(r, 400));
      setProgress(stage.p);
      setProgressStep(stage.msg);
    }

    setAnalyzing(false);
    setAnalysisDone(true);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    startAnalysis();
  };

  const handleFileSelect = () => {
    startAnalysis();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="rounded-xl border border-slate-800 bg-[#0d131f] p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold font-mono text-white tracking-tight">
              PCAP Analyzer
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 font-sans mt-0.5">
              Upload a packet capture file to analyze network traffic and detect suspicious activity.
            </p>
          </div>

          {/* Quick Test Demo Button */}
          {!analyzing && (
            <button
              onClick={() => startAnalysis()}
              className="px-3.5 py-1.5 rounded-lg border border-cyan-500/30 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 font-mono text-xs transition-colors self-start sm:self-auto"
            >
              Test sample_capture.pcap
            </button>
          )}
        </div>
      </div>

      {/* Drag & Drop Upload Panel */}
      {!analysisDone && !analyzing && (
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          className={`flex flex-col items-center justify-center p-14 rounded-2xl border-2 border-dashed transition-all bg-[#0d131f]/70 ${
            isDragging
              ? 'border-cyan-400 bg-cyan-950/20'
              : 'border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 mb-4">
            <FolderArchive className="w-8 h-8" />
          </div>

          <h3 className="font-mono text-base font-semibold text-white">
            Drop your PCAP file here
          </h3>
          <p className="text-xs font-mono text-slate-400 mt-1 mb-4">
            or
          </p>

          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileSelect}
            accept=".pcap,.pcapng"
            className="hidden"
          />

          <button
            onClick={() => fileInputRef.current?.click()}
            className="px-5 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-mono text-xs font-bold transition-all shadow-md"
          >
            Browse Files
          </button>

          <p className="mt-5 text-xs font-mono text-slate-500">
            Supported: .pcap / .pcapng
          </p>
        </div>
      )}

      {/* Mock Analyzing State */}
      {analyzing && (
        <div className="rounded-xl border border-slate-800 bg-[#0d131f] p-10 text-center shadow-sm">
          <div className="max-w-md mx-auto space-y-4">
            <div className="flex items-center justify-center gap-2 text-cyan-400 font-mono text-sm font-semibold">
              <Sparkles className="w-4 h-4 animate-spin" />
              <span>Analyzing traffic...</span>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between font-mono text-xs text-slate-400">
                <span>{progressStep}</span>
                <span className="font-bold text-cyan-400">{progress}%</span>
              </div>
              <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-800">
                <div
                  className="h-full bg-cyan-400 transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>

            <p className="text-xs font-mono text-slate-400">
              Extracting packet features...
            </p>
          </div>
        </div>
      )}

      {/* Analysis Complete Results */}
      {analysisDone && !analyzing && (
        <div className="space-y-6">
          <div className="flex items-center justify-between p-4 rounded-xl border border-emerald-500/30 bg-emerald-950/20">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              <div>
                <h3 className="font-mono text-sm font-bold text-white">
                  Analysis Complete
                </h3>
                <p className="text-xs font-mono text-slate-300">
                  capture_network_traffic.pcap processed successfully
                </p>
              </div>
            </div>

            <button
              onClick={() => setAnalysisDone(false)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-800 text-slate-300 font-mono text-xs hover:bg-slate-700 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Analyze Another</span>
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="rounded-xl border border-slate-800 bg-[#0d131f] p-4 text-center">
              <p className="text-xs font-mono text-slate-400 uppercase">Packets</p>
              <p className="text-2xl font-bold font-mono text-white mt-1">24,892</p>
            </div>

            <div className="rounded-xl border border-slate-800 bg-[#0d131f] p-4 text-center">
              <p className="text-xs font-mono text-slate-400 uppercase">Hosts</p>
              <p className="text-2xl font-bold font-mono text-cyan-400 mt-1">18</p>
            </div>

            <div className="rounded-xl border border-slate-800 bg-[#0d131f] p-4 text-center">
              <p className="text-xs font-mono text-slate-400 uppercase">Connections</p>
              <p className="text-2xl font-bold font-mono text-blue-400 mt-1">2,341</p>
            </div>

            <div className="rounded-xl border border-red-500/30 bg-red-950/20 p-4 text-center">
              <p className="text-xs font-mono text-red-300 uppercase">Threats</p>
              <p className="text-2xl font-bold font-mono text-red-400 mt-1">7</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
