export type Severity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';

export type AttackType = 
  | 'Port Scan'
  | 'SYN Flood'
  | 'ICMP Flood'
  | 'ARP Spoofing'
  | 'Brute Force';

export type AlertStatus = 'Active' | 'Investigating' | 'Resolved';

export interface AlertEvidence {
  packetsCount: number;
  responseCount: number;
  durationStr: string;
  targetCount: number;
  rawDetails: string[];
}

export interface SecurityAlert {
  id: string;
  title: string;
  severity: Severity;
  attackType: AttackType;
  sourceIp: string;
  destinationIp: string;
  sourcePort?: number;
  destinationPort?: number;
  timestamp: string;
  duration: string;
  status: AlertStatus;
  threatScore: number;
  evidence: AlertEvidence;
  aiExplanation: string;
  recommendations: string[];
  interface?: string;
}

export interface LivePacket {
  id: string;
  timestamp: string;
  sourceIp: string;
  destinationIp: string;
  protocol: 'TCP' | 'UDP' | 'ICMP' | 'ARP' | 'DNS' | 'TLS';
  sourcePort: number;
  destinationPort: number;
  size: number;
  flags: string[];
  info: string;
  isSuspicious?: boolean;
  hexPreview?: string;
}

export interface AttackReplayStep {
  id: number;
  timestamp: string;
  sourceIp: string;
  destinationIp: string;
  port: number;
  service: string;
  flags: string;
  status: 'SYN_SENT' | 'FILTERED' | 'RST_RECEIVED' | 'OPEN' | 'DROPPED';
  detail: string;
}

export interface AttackScenario {
  id: string;
  name: string;
  attackType: AttackType;
  sourceIp: string;
  targetIp: string;
  duration: string;
  packetCount: number;
  portsScanned: number;
  anomalyScore: number;
  description: string;
  steps: AttackReplayStep[];
}

export interface TopologyNode {
  id: string;
  ip: string;
  hostname: string;
  role: 'Router' | 'Server' | 'Workstation' | 'Attacker' | 'IoT' | 'Gateway';
  status: 'Normal' | 'Warning' | 'Compromised' | 'Critical';
  x: number;
  y: number;
  packetsIn: number;
  packetsOut: number;
  openPorts: number[];
  alertsCount: number;
  riskLevel: 'Low' | 'Medium' | 'High' | 'Critical';
  mac: string;
  os: string;
}

export interface TopologyLink {
  source: string;
  target: string;
  status: 'normal' | 'high-traffic' | 'attack-path';
  protocol: string;
}

export interface TopTalker {
  ip: string;
  hostname: string;
  packets: number;
  bytes: string;
  bandwidthMbps: number;
  risk: 'Critical' | 'High' | 'Medium' | 'Low';
  role: string;
}

export interface SecurityReport {
  id: string;
  name: string;
  type: 'Daily Analysis' | 'Threat Assessment' | 'Incident Forensics' | 'Executive Audit';
  generatedDate: string;
  threats: number;
  criticalCount: number;
  status: 'Ready' | 'Processing' | 'Archived';
  fileSize: string;
  author: string;
  summary: string;
  highlights: string[];
}
