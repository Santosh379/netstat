import React from 'react';
import { useLocation } from 'react-router-dom';
import { useMonitoring } from '../../context/MonitoringContext';
import { 
  Search, 
  Menu,
  Activity
} from 'lucide-react';

interface HeaderProps {
  onToggleMobileMenu: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onToggleMobileMenu }) => {
  const location = useLocation();
  const { isMonitoring, packetsPerSec } = useMonitoring();

  const routeTitles: Record<string, { title: string; subtitle: string }> = {
    '/': { title: 'Network Security Dashboard', subtitle: 'Monitor traffic, detect suspicious activity, and investigate network attacks.' },
    '/live': { title: 'Live Network Monitor', subtitle: 'Monitor network packets in real time.' },
    '/pcap': { title: 'PCAP Analyzer', subtitle: 'Upload a packet capture file to analyze network traffic and detect suspicious activity.' },
    '/alerts': { title: 'Security Alerts', subtitle: 'Detected suspicious network activity.' },
    '/replay': { title: 'Attack Replay', subtitle: 'Replay the packet sequence that triggered an alert.' },
    '/topology': { title: 'Network Topology', subtitle: 'Visual map of network hosts, server, and detected attacker.' },
    '/reports': { title: 'Security Reports', subtitle: 'Reports generated from network analysis.' },
    '/settings': { title: 'Settings', subtitle: 'Configure network interface and monitoring options.' }
  };

  const currentRoute = routeTitles[location.pathname] || {
    title: 'NetScope AI',
    subtitle: 'Detect. Analyze. Replay.'
  };

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-slate-800/80 bg-[#090d16]/90 px-4 sm:px-6 backdrop-blur-md">
      {/* Left Title & Mobile Menu */}
      <div className="flex items-center gap-3 sm:gap-4">
        <button
          onClick={onToggleMobileMenu}
          className="rounded-lg p-2 text-slate-400 hover:bg-slate-800 hover:text-white lg:hidden"
          aria-label="Toggle Navigation"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div>
          <h1 className="font-mono text-sm sm:text-base font-bold text-white tracking-tight">
            {currentRoute.title}
          </h1>
          <p className="hidden md:block text-[11px] text-slate-400 font-sans">
            {currentRoute.subtitle}
          </p>
        </div>
      </div>

      {/* Center Search Bar */}
      <div className="hidden md:flex items-center flex-1 max-w-xs lg:max-w-sm mx-4">
        <div className="relative w-full">
          <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search IP, port or protocol..."
            className="w-full rounded-lg border border-slate-800 bg-[#0d131f] py-1.5 pl-8 pr-3 text-xs font-mono text-slate-200 placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-800 bg-[#0d131f] font-mono text-xs">
          <Activity className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-slate-300">
            {isMonitoring ? `${packetsPerSec.toLocaleString()} pkt/s` : 'Capture Stopped'}
          </span>
        </div>
      </div>
    </header>
  );
};
