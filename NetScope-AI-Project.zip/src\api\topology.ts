import { mockTopologyNodes, mockTopologyLinks } from '../data/mockData';
import type { TopologyNode, TopologyLink } from '../types/network';

/**
 * Service placeholder for NetScope AI Network Topology API
 * Future integration with: NetworkX / LLDP / ARP table discovery engine
 */

export const topologyApi = {
  async getTopology(): Promise<{ nodes: TopologyNode[]; links: TopologyLink[] }> {
    await new Promise((r) => setTimeout(r, 60));
    return {
      nodes: [...mockTopologyNodes],
      links: [...mockTopologyLinks]
    };
  },

  async isolateHost(nodeId: string): Promise<boolean> {
    await new Promise((r) => setTimeout(r, 200));
    const node = mockTopologyNodes.find((n) => n.id === nodeId);
    if (node) {
      node.status = 'Compromised';
      return true;
    }
    return false;
  }
};
